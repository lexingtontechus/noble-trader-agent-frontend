# Noble Trader — Worklog

---
Task ID: 1
Agent: Main Orchestrator
Task: Create comprehensive step-by-step plan outline for Noble Trader frontend

Work Log:
- Read uploaded files: .env (Clerk keys + Alpaca URL), README-fastapibackend.md (full backend API docs), plan.md (existing plan)
- Explored current project structure: fresh Next.js 16 scaffold with shadcn/ui, TypeScript, no business logic
- Fetched FastAPI OpenAPI spec: 5 endpoints (health, regime/detect, size/kelly, risk/analyse, analyse/full) with full schemas
- Fetched Clerk docs: <Show /> component with when/fallback props, privateMetadata (backend-only read/write), Alpaca place order API (POST /v2/orders)
- Created 8-phase plan with 40+ steps covering foundation, layout, BFF API, dashboard, orders, search, shared components, and polish
- Documented file structure, DaisyUI component mapping, API route mapping, parallelization strategy, and risk mitigation

Stage Summary:
- Plan written to /home/z/my-project/plan.md
- Key decisions: JSX only, DaisyUI v5 only, Clerk v7 with <Show />, Alpaca keys in Clerk privateMetadata, BFF pattern for all API calls
- Identified 10 sub-agent tasks with parallelization groups

---
Task ID: 2
Agent: Main Orchestrator
Task: Implement all 8 phases of the Noble Trader frontend

Work Log:
- Phase 1: Installed daisyui, @clerk/nextjs, yahoo-finance2; set up .env.local with Clerk + Alpaca keys; removed all shadcn/ui components and unused deps; configured DaisyUI v5 with custom "noble" dark theme in globals.css
- Phase 1: Created layout.js with ClerkProvider, data-theme="noble"; created page.js with Clerk <Show /> auth gate; created middleware.js for route protection; created sign-in/sign-up pages
- Phase 2: Created Navbar.jsx (tabs, theme switcher, health badge, UserButton), Footer.jsx (sticky, feature badges, disclaimer), shared components (LoadingSkeleton, ErrorState, EmptyState, ThemeSwitcher)
- Phase 3: Created all BFF API routes: /api/health, /api/prices, /api/analyse, /api/alpaca/account, /api/alpaca/orders, /api/alpaca/orders/create, /api/alpaca/positions, /api/clerk/alpaca-keys, /api/clerk/alpaca-keys-status, /api/commentary
- Phase 3: Created lib files: fastapi-client.js (with retry/backoff for Render cold starts), alpaca-client.js, clerk-metadata.js, cache.js
- Phase 4: Created Dashboard, TickerCard, ComparisonTable, RegimeSummaryBanner components
- Phase 4: Created analysis components: RegimeCard, ObservationFeatures, RiskCard, RecommendationsCard, PriceChart, CommentaryCard
- Phase 5: Created OrdersPage, AlpacaKeySetup, AccountSummary, OrderHistory, OpenPositions, OrderModal
- Phase 6: Created SearchPage, SearchResults
- Fixed prop mismatches between TickerCard and analysis components (data vs regime/risk/sizing)
- Fixed RegimeCard and ObservationFeatures to handle FastAPI object-format vol_probs/trend_probs (not arrays)
- Fixed RecommendationsCard field names (fractional_f vs fractional_kelly, vol_scaled_f vs vol_scaled)
- Rewrote SearchResults to use shared analysis components instead of inline local ones
- Added CommentaryCardWrapper for AI commentary fetching per ticker
- ESLint passes with zero errors
- Dev server compiles and serves pages (HTTP 200)

Stage Summary:
- Complete Noble Trader frontend implemented with 40+ files
- All DaisyUI v5 components, no shadcn/ui
- Clerk v7 auth with <Show /> component for auth gating
- BFF API layer with 10 routes proxying FastAPI + Alpaca + Clerk privateMetadata
- Dashboard with 3 default tickers (Gold, Bitcoin, USD/EUR)
- Orders page with Alpaca key setup, order history, positions, buy/sell modal
- Search page with popular tickers, recent searches, full analysis
- AI commentary via LLM integration
- Dev server running on port 3000
---
Task ID: 1
Agent: Main
Task: Troubleshoot and fix Correlation Detection & Portfolio Optimizer errors in Portfolio page

Work Log:
- Analyzed uploaded screenshot showing "Not Found" red error bars on both Correlation Detection and Portfolio Optimizer sections
- Traced error flow: Frontend → BFF API routes → fastapi-client.js → FastAPI backend (/correlation/detect, /optimise/full)
- Confirmed both FastAPI endpoints return 404 (not deployed yet)
- Identified that CorrelationDetection auto-fires on mount when symbols.length >= 2, causing repeated 404 errors
- Identified that fastapi-client.js had no auth header support for when endpoints DO get deployed

Changes Made:
1. **fastapi-client.js** — Added `getFastAPIAuthHeaders()` function using Clerk JWT, created `fetchWithAuth()` wrapper that auto-includes auth headers, updated all API functions to use `fetchWithAuth()` instead of raw `fetchWithRetry()`, improved JSON error parsing in `fetchWithRetry`
2. **PortfolioOverview.jsx** — Added `ComingSoonCard` component with friendly "Coming Soon" UI, added `endpointAvailable` state tracking to both CorrelationDetection and PortfolioOptimizer, when ENDPOINT_NOT_DEPLOYED detected → switches to ComingSoonCard instead of red error, added `hasAutoFired` ref to prevent repeated auto-detection attempts, added "Check Again" retry button on ComingSoonCard that resets state and retries, filtered out ENDPOINT_NOT_DEPLOYED from error display (shown via ComingSoonCard instead)
3. **API routes (correlation, optimizer)** — Improved error message matching (case-insensitive), added auth-related error detection (401/403), improved hint messages

Stage Summary:
- Both Correlation Detection and Portfolio Optimizer now show a friendly "Coming Soon" card with info icon instead of red "Not Found" error
- Auto-retry is prevented after first ENDPOINT_NOT_DEPLOYED failure to reduce unnecessary server load
- Auth headers are now forwarded to FastAPI backend for when endpoints are deployed
- All changes pass lint with no errors
